package visitor;

public class Code {

	public String temp = null;
	
	public String code = null;
	
	public Code(String t,String c) {
		this.code = c;
		this.temp = t;
	}
	
}
