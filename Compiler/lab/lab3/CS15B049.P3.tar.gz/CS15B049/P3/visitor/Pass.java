package visitor;

public class Pass {
	Data data ;
	Method mth ;
	
	public Pass(Data data,Method mth) {
		this.data = data;
		this.mth = mth;
	}
	
}
