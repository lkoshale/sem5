package visitor;

public class Range {
	public int start;
	public int end;
}
